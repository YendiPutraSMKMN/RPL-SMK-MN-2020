<html>
<head><title>Belajar PHP</title></head>
<body>
<h3>Floating Point</h3>
<?php
//inisialisasi
$a = 2;
$b = 30.10;//float
$c = 6000000;//
$hasil = $a + $b + $c;
//operasi
echo "Jumlah semuanya adalah ".$hasil;
/*output program menampilkan suatu hasil perhitungan var floating point dengan perbedaan
inisialisasi masing-masing tipe data*/
?>
</body>
</html>