<html>
<head><title>Belajar PHP</title></head>
<body>
<h3>Var Server Web</h3>
<?php
echo $DOCUMENT_ROOT;
echo "Direktori script ini berada di ".$DOCUMENT_ROOT."<br>";
echo "Script ini bernama ".$PHP_SELF."<br>";
echo "Browser yang anda gunakan adalah ".$HTTP_SERVER_VARS['HTTP_USER_AGENT'];
echo "Ip yang anda gunakan adalah ".$HTTP_SERVER_VARS['REMOTE_ADDR'];
echo "Server yang anda akses adalah ".$HTTP_SERVER_VARS['SERVER_NAME'];
echo "Server anda ".$HTTP_SERVER_VARS['SERVER_SOFTWARE'];
echo "Port server yang anda akses ".$HTTP_SERVER_VARS['SERVER_PORT'];
echo "Protocol yang digunakan ".$HTTP_SERVER_VARS['SERVER_PROTOCOL'];



?>
</body>
</html>
