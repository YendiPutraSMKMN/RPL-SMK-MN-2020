<html>
<head><title>Belajar PHP</title></head>
<body>
<h3>Array</h3>
<?php
//array index angka, cara 1
$nilai[0] = 6;//membuat var array dan mengisinya dengan tipe integer
$nilai[1] = 9;
$nilai[2] = 8; 
echo "Jumlah semua nilainya : ".$nilai[0] + $nilai[1] + $nilai[2]."<hr>";
//array index angka cara 2
$nilai_b = array ( 0=>6,1=>9,2=>8);
echo "Jumlah semua nilainya : ".$nilai_b[0] + $nilai_b[1] + $nilai_b[2]."<hr>";
//array index string
$harga["roti"] = 2000;
$harga["nasi"] = 3000;
echo "Harga roti ".$harga["roti"]." dan harga nasi ".$harga["nasi"];

/*source code diatas mengajari kita untuk memahami cara menggunakan dan mengakses array
dengan index berupa integer dan string*/
?>
</body>
</html>
