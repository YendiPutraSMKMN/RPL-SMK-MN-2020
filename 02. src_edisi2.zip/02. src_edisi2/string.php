<html>
<head><title>Belajar PHP</title></head>
<body>
<h3>String</h3>
<?php
//inisialisasi
$kata  = "Dengan petik ganda";
$kata2 = 'Dengan petik tunggal';
//operasi
echo $kata."<br>".$kata2;
/*output program menampilkan suatu nilai string dengan 2 cara*/
?>
</body>
</html>
