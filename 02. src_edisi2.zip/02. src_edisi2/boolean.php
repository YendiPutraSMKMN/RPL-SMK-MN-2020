<html>
<head><title>Belajar PHP</title></head>
<body>
<h3>Boolean</h3>
<?php
//inisialisasi
$x = TRUE;
$y = FALSE;
//operasi
echo $x = $x."<br>";
echo $y = $y;
/*output program hanya akan menghasilkan nilai 1, sebab jika benar ketemu benar 
jawabannya adalah benar, jika salah ketemu salah jawabannya salah, dan tidak 
menghasilkan apapun*/
?>
</body>
</html>
