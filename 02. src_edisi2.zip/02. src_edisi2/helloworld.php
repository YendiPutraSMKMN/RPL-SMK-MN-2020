<html>
<head><title>Belajar PHP</title></head>
<body>
<h3>Variabel Server Web</h3>
<?

$a = 12;//variabel global

function tampil(){
	$b = 20;//variabel lokal
	echo $b;
}
echo tampil();
?>
</body>
</html>
