<html>
<head><title>Belajar PHP</title></head>
<body>
<h3>Integer</h3>
<?php
//inisialisasi
$panjang = 40;
$lebar = 50;
$luas = $panjang * $lebar;
$tahun_lahir=2002;
$tahun_sekarang=2020;
$usia=$tahun_sekarang-$tahun_lahir;
//operasi
echo "Luasnya ".$luas."<br>";
echo "usia saya adalah ".$usia." Tahun";

/*output program menampilkan suatu hasil perhitungan var integer panjang dan lebar*/
?>
</body>
</html>
