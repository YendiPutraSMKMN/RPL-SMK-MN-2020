<html>
<head><title>Belajar PHP</title></head>
<body>
<h3>Variabel Global</h3>
<?php
$a = 12;//variabel global

function tampil(){
	global $a;//mengakses var global
	echo $a;
}
echo tampil(); 
?>
</body>
</html>
