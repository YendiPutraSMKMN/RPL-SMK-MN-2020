<html>
<head><title>Belajar PHP</title></head>
<body>
<h3>Variabel Lokal</h3>
<?php
$a = 12;//variabel global

function tampil(){
	$b = 20;//variabel lokal
	echo $b;
}
echo tampil();
?>
</body>
</html>
